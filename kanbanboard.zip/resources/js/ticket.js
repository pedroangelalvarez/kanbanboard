import './bootstrap';


require('./components/IndexTicket');