import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Incidente from './Incidente';

ReactDOM.render(
  <React.StrictMode>
    <Incidente />
  </React.StrictMode>,
  document.getElementById('root')
);