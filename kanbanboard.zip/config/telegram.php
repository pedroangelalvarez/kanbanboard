<?php

return [
    'bot_token' => env('TELEGRAM_BOT_TOKEN'),
];